# RADAR — Android game prototype

A mobile-first stealth maze game built with Godot 4.3.

## Current prototype
- Landscape touch controls (left virtual stick).
- FOCUS radar: dense forward fan of wall-return points.
- 360° radar: sparse full-circle wall-return points.
- Radar pulses briefly reveal wall contact points and alert nearby enemies.
- Player marker is shown for 5 seconds after firing.
- Enemies are always visible, move slowly, and react to radar noise.
- Footsteps are only detected with an unobstructed line of sight.
- Tablet map displays maze, coins, enemies and player.
- Collect 150 coins to win (the generated maze currently places as many as fit).

## Build APK using GitHub Actions
1. Create a GitHub repository named `RADAR`.
2. Upload the contents of this project (not the enclosing folder) to the repository.
3. Open **Actions** and enable workflows if GitHub asks.
4. Run **Build Android APK** from the Actions tab, or push a commit.
5. Open the completed workflow run and download the `RADAR-Android-Debug` artifact.
6. Extract the ZIP on your Android phone and install the APK. Android may ask you to allow installs from your browser/file manager.

The workflow uses the Godot 4.3 CI image and exports a debug APK. The APK is unsigned for Play Store distribution; it is intended for direct testing on your phone.

## Important
This is a first playable prototype. It uses a procedurally generated maze and a simple enemy hearing/roaming model. Further balancing, sound effects, menus, save data, and performance testing can be added after the first phone test.
