extends Node2D

# RADAR prototype: touch-first, landscape, single-screen top-down maze.
const TILE := 48.0
const MAP_W := 35
const MAP_H := 25
const PLAYER_SPEED := 175.0
const ENEMY_SPEED := 62.0
const COIN_TARGET := 150
const PULSE_RANGE := 390.0
const PULSE_LIFETIME := 2.6
const PLAYER_PING_TIME := 5.0

var grid: Array = []
var player := Vector2( TILE * 1.5, TILE * 1.5 )
var facing := Vector2.RIGHT
var enemies: Array[Dictionary] = []
var coins: Array[Vector2] = []
var collected := 0
var pulses: Array[Dictionary] = []
var player_ping := 0.0
var pulse_cooldown := 0.0
var tablet_open := false
var message := "Find 150 coins. Radar reveals the maze."
var message_time := 4.0
var joy_origin := Vector2(112, 420)
var joy_vector := Vector2.ZERO
var touch_points := {}
var game_won := false
var rng := RandomNumberGenerator.new()

func _ready() -> void:
	rng.randomize()
	_make_maze()
	_place_coins()
	_place_enemies()
	set_process(true)

func _make_maze() -> void:
	# Start with solid walls, then carve a connected maze using randomized DFS.
	grid.clear()
	for y in range(MAP_H):
		var row: Array = []
		for x in range(MAP_W):
			row.append(1)
		grid.append(row)
	var stack: Array[Vector2i] = [Vector2i(1, 1)]
	grid[1][1] = 0
	while not stack.is_empty():
		var cur: Vector2i = stack.back()
		var dirs: Array[Vector2i] = [Vector2i(0,-2), Vector2i(2,0), Vector2i(0,2), Vector2i(-2,0)]
		dirs.shuffle()
		var carved := false
		for d in dirs:
			var nxt := cur + d
			if nxt.x > 0 and nxt.x < MAP_W - 1 and nxt.y > 0 and nxt.y < MAP_H - 1 and grid[nxt.y][nxt.x] == 1:
				grid[cur.y + int(d.y/2)][cur.x + int(d.x/2)] = 0
				grid[nxt.y][nxt.x] = 0
				stack.append(nxt)
				carved = true
				break
		if not carved:
			stack.pop_back()
	# A few extra openings keep navigation less punishing.
	for i in range(28):
		var x := rng.randi_range(1, MAP_W - 2)
		var y := rng.randi_range(1, MAP_H - 2)
		if rng.randf() < 0.38:
			grid[y][x] = 0
	grid[1][1] = 0

func _place_coins() -> void:
	coins.clear()
	var open_cells: Array[Vector2i] = []
	for y in range(1, MAP_H - 1):
		for x in range(1, MAP_W - 1):
			if grid[y][x] == 0 and Vector2(x*TILE+TILE/2, y*TILE+TILE/2).distance_to(player) > 90:
				open_cells.append(Vector2i(x,y))
	open_cells.shuffle()
	for i in range(min(COIN_TARGET, open_cells.size())):
		coins.append(Vector2(open_cells[i].x*TILE+TILE/2, open_cells[i].y*TILE+TILE/2))

func _place_enemies() -> void:
	enemies.clear()
	var spots := [Vector2( MAP_W-2, 1), Vector2( MAP_W-2, MAP_H-2), Vector2(1, MAP_H-2), Vector2(12,8)]
	for s in spots:
		var p := Vector2(s.x*TILE+TILE/2, s.y*TILE+TILE/2)
		if not _is_wall_world(p):
			enemies.append({"pos":p, "target":p, "alert":0.0, "wander":0.0})

func _process(delta: float) -> void:
	if game_won:
		queue_redraw()
		return
	pulse_cooldown = maxf(0.0, pulse_cooldown-delta)
	player_ping = maxf(0.0, player_ping-delta)
	message_time = maxf(0.0, message_time-delta)
	for i in range(pulses.size()-1, -1, -1):
		pulses[i].life -= delta
		if pulses[i].life <= 0:
			pulses.remove_at(i)
	_move_player(delta)
	_update_enemies(delta)
	_collect_coins()
	queue_redraw()

func _move_player(delta: float) -> void:
	var input_dir := joy_vector
	if not tablet_open and input_dir.length() > 0.12:
		facing = input_dir.normalized()
		var velocity := facing * PLAYER_SPEED * delta
		_try_move_player(Vector2(velocity.x, 0))
		_try_move_player(Vector2(0, velocity.y))

func _try_move_player(amount: Vector2) -> void:
	var next := player + amount
	if not _is_wall_world(next + Vector2(-12,-12)) and not _is_wall_world(next + Vector2(12,-12)) and not _is_wall_world(next + Vector2(-12,12)) and not _is_wall_world(next + Vector2(12,12)):
		player = next

func _update_enemies(delta: float) -> void:
	for e in enemies:
		var ep: Vector2 = e.pos
		var heard := false
		# Radar pulses are audible through walls within a limited radius.
		for p in pulses:
			if ep.distance_to(p.origin) <= PULSE_RANGE:
				heard = true
				e.target = p.origin
				e.alert = 5.0
				break
		# Footsteps are heard only with unobstructed line of sight.
		if not heard and _line_clear(ep, player) and ep.distance_to(player) < 145.0 and joy_vector.length() > 0.15:
			e.target = player
			e.alert = 2.2
		e.alert = maxf(0.0, e.alert-delta)
		e.wander -= delta
		if e.alert <= 0.0 and e.wander <= 0.0:
			var cell := Vector2i(rng.randi_range(1,MAP_W-2), rng.randi_range(1,MAP_H-2))
			if grid[cell.y][cell.x] == 0:
				e.target = Vector2(cell.x*TILE+TILE/2, cell.y*TILE+TILE/2)
			e.wander = rng.randf_range(2.0, 5.0)
		var diff: Vector2 = e.target - ep
		if diff.length() > 5:
			var step := diff.normalized() * ENEMY_SPEED * delta
			var candidate := ep + step
			if not _is_wall_world(candidate):
				e.pos = candidate
			else:
				e.wander = 0.0

func _collect_coins() -> void:
	for i in range(coins.size()-1, -1, -1):
		if player.distance_to(coins[i]) < 22:
			coins.remove_at(i)
			collected += 1
			message = "Coin collected: %d / %d" % [collected, COIN_TARGET]
			message_time = 1.5
			if collected >= COIN_TARGET:
				game_won = true
				message = "YOU ESCAPED! 150 / 150"
				message_time = 999.0

func _is_wall_world(p: Vector2) -> bool:
	var x := int(floor(p.x / TILE))
	var y := int(floor(p.y / TILE))
	if x < 0 or y < 0 or x >= MAP_W or y >= MAP_H:
		return true
	return grid[y][x] == 1

func _line_clear(a: Vector2, b: Vector2) -> bool:
	var distance := a.distance_to(b)
	var steps := int(distance / 12.0)
	for i in range(1, steps):
		if _is_wall_world(a.lerp(b, float(i)/maxi(steps,1))):
			return false
	return true

func _fire_radar(full_circle: bool) -> void:
	if pulse_cooldown > 0.0 or tablet_open:
		return
	pulse_cooldown = 1.1 if full_circle else 0.45
	player_ping = PLAYER_PING_TIME
	var count := 36 if full_circle else 72
	var arc_center := facing.angle()
	for i in range(count):
		var angle: float
		if full_circle:
			angle = TAU * float(i) / count
		else:
			angle = arc_center - deg_to_rad(48) + deg_to_rad(96) * float(i) / maxf(1.0, count-1)
		var dir := Vector2.RIGHT.rotated(angle)
		var hit := player + dir * PULSE_RANGE
		var d := 8.0
		while d < PULSE_RANGE:
			var point := player + dir*d
			if _is_wall_world(point):
				hit = point
				break
			d += 8.0
		pulses.append({"origin":player, "point":hit, "life":PULSE_LIFETIME, "max":PULSE_LIFETIME})
	message = "360° PULSE — enemies may hear you" if full_circle else "FOCUS PULSE — enemies may hear you"
	message_time = 2.0

func _input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		if event.pressed:
			touch_points[event.index] = event.position
			_handle_tap(event.position)
		else:
			touch_points.erase(event.index)
			_update_joystick()
	elif event is InputEventScreenDrag:
		touch_points[event.index] = event.position
		_update_joystick()
	elif event is InputEventMouseButton and event.pressed:
		_handle_tap(event.position)
	elif event is InputEventMouseMotion and Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT):
		joy_vector = _joy_from_pos(event.position)

func _handle_tap(pos: Vector2) -> void:
	if pos.x < 235 and pos.y > 300:
		joy_vector = _joy_from_pos(pos)
	elif pos.x > 790 and pos.y > 390:
		_fire_radar(false)
	elif pos.x > 790 and pos.y > 275 and pos.y <= 390:
		_fire_radar(true)
	elif pos.x > 790 and pos.y > 150 and pos.y <= 275:
		tablet_open = not tablet_open
		joy_vector = Vector2.ZERO

func _update_joystick() -> void:
	joy_vector = Vector2.ZERO
	for p in touch_points.values():
		if p.x < 260 and p.y > 280:
			joy_vector = _joy_from_pos(p)
			break

func _joy_from_pos(pos: Vector2) -> Vector2:
	var center := Vector2(112,420)
	var v := pos-center
	return v.limit_length(1.0)

func _draw() -> void:
	var screen := get_viewport_rect().size
	draw_rect(Rect2(Vector2.ZERO,screen), Color(0.012,0.016,0.025))
	# Only radar returns reveal walls. The enemies remain visible at all times.
	for pulse in pulses:
		var alpha: float = clampf(pulse.life / pulse.max, 0.0, 1.0)
		draw_line(_world_to_screen(pulse.origin), _world_to_screen(pulse.point), Color(0.15,0.95,1.0,alpha), 2.0)
		draw_circle(_world_to_screen(pulse.point), 3.0, Color(0.5,1.0,1.0,alpha))
	# Enemy silhouettes are always visible.
	for e in enemies:
		var ep: Vector2 = e.pos
		draw_circle(_world_to_screen(ep), 11, Color(1.0,0.20,0.22))
		draw_circle(_world_to_screen(ep), 4, Color(1.0,0.75,0.7))
	# Player marker briefly appears after every radar pulse.
	if player_ping > 0:
		draw_circle(_world_to_screen(player), 9, Color(0.2,1.0,0.45))
		draw_arc(_world_to_screen(player), 18, 0, TAU, 32, Color(0.2,1.0,0.45,0.7), 2)
	# HUD
	draw_string(ThemeDB.fallback_font, Vector2(22,34), "RADAR", HORIZONTAL_ALIGNMENT_LEFT, -1, 22, Color(0.3,0.95,1))
	draw_string(ThemeDB.fallback_font, Vector2(22,62), "COINS  %03d / 150" % collected, HORIZONTAL_ALIGNMENT_LEFT, -1, 17, Color.WHITE)
	if message_time > 0:
		draw_string(ThemeDB.fallback_font, Vector2(250,34), message, HORIZONTAL_ALIGNMENT_LEFT, 450, 15, Color(0.7,0.95,1))
	# Touch controls
	draw_arc(Vector2(112,420), 58, 0, TAU, 48, Color(0.4,0.85,0.95,0.5), 3)
	draw_circle(Vector2(112,420), 8, Color(0.4,0.85,0.95,0.45))
	draw_circle(Vector2(112,420)+joy_vector*34, 18, Color(0.3,0.8,0.95,0.55))
	_button(Vector2(850,445), "FOCUS", Color(0.05,0.42,0.52))
	_button(Vector2(850,330), "360°", Color(0.05,0.32,0.42))
	_button(Vector2(850,215), "TABLET", Color(0.18,0.25,0.42))
	if tablet_open:
		_draw_tablet(screen)
	if game_won:
		draw_rect(Rect2(Vector2(0,0),screen), Color(0,0,0,0.75))
		draw_string(ThemeDB.fallback_font, screen/2 + Vector2(-125,0), "YOU ESCAPED!", HORIZONTAL_ALIGNMENT_LEFT, -1, 32, Color(0.3,1,0.65))

func _button(center: Vector2, label: String, color: Color) -> void:
	draw_circle(center, 48, color)
	draw_arc(center, 48, 0, TAU, 48, Color(0.4,0.9,1,0.8), 2)
	draw_string(ThemeDB.fallback_font, center+Vector2(-37,6), label, HORIZONTAL_ALIGNMENT_CENTER, 74, 14, Color.WHITE)

func _world_to_screen(p: Vector2) -> Vector2:
	# Keep the player centered; maze remains hidden except where radar points strike.
	return get_viewport_rect().size/2 + (p-player)

func _draw_tablet(screen: Vector2) -> void:
	draw_rect(Rect2(Vector2(150,48),screen-Vector2(300,96)), Color(0.015,0.035,0.06,0.97))
	draw_rect(Rect2(Vector2(150,48),screen-Vector2(300,96)), Color(0.25,0.8,0.95), false, 2)
	var scale := minf((screen.x-360)/(MAP_W*TILE), (screen.y-150)/(MAP_H*TILE))
	var map_size := Vector2(MAP_W*TILE, MAP_H*TILE)*scale
	var origin := (screen-map_size)/2
	for y in range(MAP_H):
		for x in range(MAP_W):
			if grid[y][x] == 1:
				draw_rect(Rect2(origin+Vector2(x,y)*TILE*scale,Vector2.ONE*TILE*scale), Color(0.18,0.38,0.48))
	for c in coins:
		draw_circle(origin+c*scale, 2.4, Color(1.0,0.82,0.2))
	for e in enemies:
		draw_circle(origin+(e.pos)*scale, 4, Color(1,0.2,0.2))
	draw_circle(origin+player*scale, 4, Color(0.2,1,0.45))
	draw_string(ThemeDB.fallback_font, Vector2(170,76), "TABLET MAP  •  TAP TABLET TO CLOSE", HORIZONTAL_ALIGNMENT_LEFT, -1, 14, Color(0.5,0.95,1))
